<?php
include('loggedin.php');
print newpostbox($userid);
?>
