<form action="login.php" method="post">
<table class="container" align="center" cellspacing="0" cellpadding="0">
   <tr>
      <td colspan="2" style="text-align:center;"><h1>Log In</h1></td>
   </tr>
   <tr>
      <td>Username:</td>
      <td><input type="text" name="username" maxlength="20" /></td>
   </tr>
   <tr>
      <td>Password:</td>
      <td><input type="password" name="password" /></td>
   </tr>
   <tr>
      <td colspan="2" style="text-align:center;"><input name="login" type="submit" value="Log In" /></td>
   </tr>
   <tr>
      <td colspan="2" style="text-align:center;"><a href="register.php">Register</a> | <a href="index.php">Index</a></td>
   </tr>
</table>
</form>
