<html>
<head>
<title><?php echo $current_page ?></title>
<LINK REL=stylesheet HREF="main.css" TYPE="text/css">
<script src="prototype.js"></script>
<script src="chat.js"></script>
<script src="rico.js"></script>
</head>
<body onLoad="scrollDown();">

